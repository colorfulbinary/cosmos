#pragma once

#define szSCCRED_FILENAME                                   "SCCRED01"
#define cbMAX_CRED_FILE                                     1024

typedef struct _SCHELP_CONTEXT
{
    LPWSTR wszUserName;
    LPWSTR wszPassword;
    LPWSTR wszDomainName;
} SCHELP_CONTEXT, *PSCHELP_CONTEXT;

DWORD
WINAPI
ScHelpInit(
    __in        PSCHELP_CONTEXT pCtx);

void
WINAPI
ScHelpCleanup(
    __inout     PSCHELP_CONTEXT pCtx);

DWORD
WINAPI
ScHelpPackCred(
    __in                    LPWSTR wszUserName,
    __in                    LPWSTR wszPassword,
    __in                    LPWSTR wszDomainName,
    __out_bcount(*pcbCred)  PBYTE pbCred,
    __inout                 PDWORD pcbCred);
