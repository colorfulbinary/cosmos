/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

This code is adopted from the PropCert Platform SDK sample.  Here's the 
original disclaimer:


 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

------------------------------------------------------------------------------*/

///////////////
//
// INCLUDE
//

#include <stdafx.h>
#include "mgsc.h"
#include "schelp.h"

//
// Heap memory management routines
//

LPVOID 
WINAPI
Alloc(
    __in            SIZE_T cBytes)
{
    return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, cBytes);
}

void
WINAPI
Free(
    __in            LPVOID pvMem)
{
    HeapFree(GetProcessHeap(), 0, pvMem);
}

//
// Build a credential byte array from the indicated components
// 
DWORD
WINAPI
ScHelpPackCred(
    __in                    LPWSTR wszUserName,
    __in                    LPWSTR wszPassword,
    __in                    LPWSTR wszDomainName,
    __out_bcount(*pcbCred)  PBYTE pbCred,
    __inout                 PDWORD pcbCred)
{
    DWORD status = ERROR_SUCCESS;
    DWORD cbTotal = 0;
    DWORD cbCurrent = 0;

    __try
    {
        cbTotal = (DWORD) sizeof(WCHAR) *
            ((1 + wcslen(wszUserName)) +
             (1 + wcslen(wszPassword)) +
             (1 + wcslen(wszDomainName)));

        if (*pcbCred < cbTotal)
        {
            *pcbCred = cbTotal;
            if (NULL != pbCred)
                status = ERROR_INSUFFICIENT_BUFFER;
            __leave;
        }

        cbTotal = 0;
        cbCurrent = (DWORD) sizeof(WCHAR) * (1 + wcslen(wszUserName));
        memcpy(pbCred + cbTotal, wszUserName, cbCurrent);
        cbTotal += cbCurrent;

        cbCurrent = (DWORD) sizeof(WCHAR) * (1 + wcslen(wszPassword));
        memcpy(pbCred + cbTotal, wszPassword, cbCurrent);
        cbTotal += cbCurrent;

        cbCurrent = (DWORD) sizeof(WCHAR) * (1 + wcslen(wszDomainName));
        memcpy(pbCred + cbTotal, wszDomainName, cbCurrent);
    }
    __finally
    {
    }

    return status;
}

//
// Break down the credential byte array
// 
DWORD
WINAPI
_UnpackCred(
    __in_bcount(cbCred)     PBYTE pbCred,
    __in                    DWORD cbCred,
    __out                   LPWSTR *ppwszUserName,
    __out                   LPWSTR *ppwszPassword,
    __out                   LPWSTR *ppwszDomainName)
{
    DWORD status = ERROR_SUCCESS;
    DWORD cbUserName = 0;
    DWORD cbPassword = 0;
    DWORD cbDomainName = 0;
    DWORD cbCurrent = 0;

    *ppwszUserName = NULL;
    *ppwszPassword = NULL;
    *ppwszDomainName = NULL;

    __try
    {
        //
        // Read the user name
        // 

        cbUserName = (DWORD) sizeof(WCHAR) * (1 + wcslen(
            (LPWSTR) (pbCred + cbCurrent)));
        if (cbUserName > cbCred - cbCurrent)
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (NULL == (*ppwszUserName = (LPWSTR) Alloc(cbUserName)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (FAILED(StringCbCopy(
            *ppwszUserName, cbUserName, (LPWSTR) (pbCred + cbCurrent))))
        {
            status = ERROR_INSUFFICIENT_BUFFER;
            __leave;
        }

        cbCurrent += cbUserName;

        //
        // Read the password
        // 

        cbPassword = (DWORD) sizeof(WCHAR) * (1 + wcslen(
            (LPWSTR) (pbCred + cbCurrent)));
        if (cbPassword > cbCred - cbCurrent)
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (NULL == (*ppwszPassword = (LPWSTR) Alloc(cbPassword)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (FAILED(StringCbCopy(
            *ppwszPassword, cbPassword, (LPWSTR) (pbCred + cbCurrent))))
        {
            status = ERROR_INSUFFICIENT_BUFFER;
            __leave;
        }

        cbCurrent += cbPassword;

        //
        // Read the domain name (if any)
        // 

        cbDomainName = (DWORD) sizeof(WCHAR) * (1 + wcslen(
            (LPWSTR) (pbCred + cbCurrent)));
        if (sizeof(WCHAR) == cbDomainName)
            __leave;
        else if (cbDomainName > cbCred - cbCurrent)
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (NULL == (*ppwszDomainName = (LPWSTR) Alloc(cbDomainName)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (FAILED(StringCbCopy(
            *ppwszDomainName, cbDomainName, (LPWSTR) (pbCred + cbCurrent))))
        {
            status = ERROR_INSUFFICIENT_BUFFER;
            __leave;
        }
    }
    __finally
    {

    }

    return status;
}

//
// Establish a card module based connection to the card in the specified reader.
//
DWORD
WINAPI
_Connect(
    __in                SCARDCONTEXT hSCardCtx,
    __in                LPWSTR wszReaderName,
    __out               PMGSC_CONTEXT pMgscCtx,
    __out               SCARDHANDLE *phSCardHandle,
    __out               PBOOL pfTransacted)
{
    DWORD status = ERROR_SUCCESS;
    DWORD dwProtocol = 0;
    LPWSTR wszCardName = NULL;
    DWORD cchCardName = SCARD_AUTOALLOCATE;
    LPWSTR wszTempReader = NULL;
    DWORD cchTempReader = SCARD_AUTOALLOCATE;
    DWORD dwState = 0;
    PBYTE pbAtr = NULL;
    DWORD cbAtr = SCARD_AUTOALLOCATE;

    *pfTransacted = FALSE;

    __try
    {
        //
        // Connect to the card
        //

        if (ERROR_SUCCESS != (status = SCardConnect(
                hSCardCtx, 
                wszReaderName, 
                SCARD_SHARE_SHARED, 
                SCARD_PROTOCOL_Tx, 
                phSCardHandle, 
                &dwProtocol)))
            __leave;

        //
        // Get the ATR
        //

        if (ERROR_SUCCESS != (status = SCardStatus(
                *phSCardHandle,
                (LPWSTR) &wszTempReader,
                &cchTempReader,
                &dwState,
                &dwProtocol,
                (PBYTE) &pbAtr,
                &cbAtr)))
            __leave;

        //
        // Get the card name
        //

        if (ERROR_SUCCESS != (status = SCardListCards(
                hSCardCtx,
                pbAtr,
                NULL,
                0,
                (LPWSTR) &wszCardName,
                &cchCardName)))
            __leave;

        //
        // Lock the card
        //

        if (ERROR_SUCCESS != (status = SCardBeginTransaction(*phSCardHandle)))
            __leave;

        *pfTransacted = TRUE;

        //
        // Bind to the card module
        //

        if (ERROR_SUCCESS != (status = MgScCardAcquireContext(
                pMgscCtx,
                hSCardCtx,
                *phSCardHandle,
                wszCardName,
                pbAtr,
                cbAtr,
                0)))
            __leave;
    }
    __finally
    {
        if (NULL != wszTempReader)
            SCardFreeMemory(hSCardCtx, wszTempReader);
        if (NULL != pbAtr)
            SCardFreeMemory(hSCardCtx, pbAtr);
        if (NULL != wszCardName)
            SCardFreeMemory(hSCardCtx, wszCardName);
    }

    return status;
}

//
// Read credentials from the specified readers
// 
DWORD 
WINAPI
_ReadCreds(
    __in        SCARDCONTEXT hContext,
    __in        LPCTSTR mszReaderNames,
    __inout     PSCHELP_CONTEXT pCtx)
{
   DWORD status = ERROR_SUCCESS;
   LPSCARD_READERSTATE lpReaderStates = NULL;
   DWORD dwNumReaders = 0;
   LPCTSTR szReaderName = NULL;
   BYTE rgbData [cbMAX_CRED_FILE];
   DWORD cbData = 0;
   MGSC_CONTEXT MgscCtx = {0};
   BOOL fCleanupMgsc = FALSE;
   SCARDHANDLE hCard = 0;
   BOOL fTransacted = FALSE;

   //
   // Make sure pointer parameters are not NULL.
   //
   if (mszReaderNames == NULL)
   {
      return (DWORD) SCARD_E_INVALID_PARAMETER;
   }

   __try
   {
      //
      // Count number of readers.
      //
      for (dwNumReaders = 0, szReaderName = mszReaderNames;
           *szReaderName != _T('\0');
           dwNumReaders++)
      {
         szReaderName += lstrlen(szReaderName) + 1;
      }

      //
      // Allocate memory for SCARD_READERSTATE array.
      //
      lpReaderStates = (LPSCARD_READERSTATE)
                       Alloc(dwNumReaders * sizeof(SCARD_READERSTATE));
      if (lpReaderStates == NULL)
      {
         status = (DWORD) SCARD_E_NO_MEMORY;
         __leave;
      }

      //
      // Prepare state array.
      //
      ZeroMemory((LPVOID) lpReaderStates,
                 dwNumReaders * sizeof(SCARD_READERSTATE));

      DWORD i;
      for (i = 0, szReaderName = mszReaderNames;
           i < dwNumReaders;
           i++)
      {
         lpReaderStates[i].szReader = (LPCTSTR) szReaderName;
         lpReaderStates[i].dwCurrentState = SCARD_STATE_UNAWARE;

         szReaderName += lstrlen(szReaderName) + 1;
      }

      //
      // Initialize card status.
      //
      status = SCardGetStatusChange(hContext,
                                     INFINITE,
                                     lpReaderStates,
                                     dwNumReaders);
      if (status != SCARD_S_SUCCESS)
      {
         __leave;
      }

      //
      // For each card found, find the proper CSP and propagate the
      // certificate(s) to the specified local store.
      //
      for (i = 0; i < dwNumReaders && status == SCARD_S_SUCCESS; i++)
      {
          //
          // Card in this reader?
          //

          if (!(lpReaderStates[i].dwEventState & SCARD_STATE_PRESENT))
          {
             //
             // No card in this reader.
             //
             continue;
          }

          //
          // Bind to the card
          // 

          if (ERROR_SUCCESS != (status = _Connect(
              hContext,
              (LPWSTR) lpReaderStates [i].szReader,
              &MgscCtx,
              &hCard,
              &fTransacted)))
          {
              __leave;
          }

          fCleanupMgsc = TRUE;

          //
          // Read the credential file from the card
          // 

          cbData = sizeof(rgbData);
          if (ERROR_SUCCESS != (status = MgScCardReadFile(
                  &MgscCtx, 
                  NULL,
                  szSCCRED_FILENAME,
                  0,
                  rgbData,
                  &cbData)))
              __leave;

          //
          // Parse the credential
          // 

          if (ERROR_SUCCESS != (status = _UnpackCred(
                  rgbData,
                  cbData,
                  &pCtx->wszUserName,
                  &pCtx->wszPassword,
                  &pCtx->wszDomainName)))
              __leave;
      }
   }
   __finally
   {
       SecureZeroMemory(rgbData, cbData);
       if (lpReaderStates != NULL)
           Free((LPVOID) lpReaderStates);
       if (TRUE == fTransacted)
           SCardEndTransaction(hCard, SCARD_LEAVE_CARD);
       if (0 != hCard)
           SCardDisconnect(hCard, SCARD_LEAVE_CARD);
       if (TRUE == fCleanupMgsc)
           MgScCardDeleteContext(&MgscCtx);
   }

   return status;
}

//
// Procedure for reading all available credentials from all available
// smart card readers.
// 
// This is adapted from the previous propcert.cpp!main entry point
// 
DWORD
WINAPI
_ScHelpThreadProc(
    __in        PSCHELP_CONTEXT pCtx)
{
   DWORD status = ERROR_SUCCESS;
   SCARDCONTEXT hContext = NULL;
   LPTSTR mszReaderNames = NULL;

   UNREFERENCED_PARAMETER(pCtx);

   __try
   {
      //
      // Establish context with the resource manager.
      //
      status = SCardEstablishContext(SCARD_SCOPE_USER,
                                      NULL,
                                      NULL,
                                      &hContext);
      if (status != SCARD_S_SUCCESS)
      {
         __leave;
      }

      //
      // Get the list of reader(s) associated with the specified group(s).
      // Note: The buffer is automatically allocated and must be freed
      //       by SCardFreeMemory().
      //
      DWORD dwAutoAllocate = SCARD_AUTOALLOCATE;

      status = SCardListReaders(hContext,
                                 SCARD_DEFAULT_READERS,
                                 (LPTSTR) &mszReaderNames,
                                 &dwAutoAllocate);
      if (status != SCARD_S_SUCCESS)
      {
         __leave;
      }

      //
      // Propagate all digital certificate(s) found in all reader(s) to the
      // certificate store.
      //
      status = _ReadCreds(hContext, mszReaderNames, pCtx);
   }
   __finally
   {
      if (mszReaderNames != NULL)
          SCardFreeMemory(hContext, (LPVOID) mszReaderNames);
      if (hContext != NULL)
          SCardReleaseContext(hContext);
   }

   return status;
}

//
// Initialize the credential gathering thread
// 
DWORD
WINAPI
ScHelpInit(
    __inout     PSCHELP_CONTEXT pCtx)
{
    DWORD status = ERROR_SUCCESS;

    __try
    {
        //
        // Grab the credentials synchronously
        // 

        if (ERROR_SUCCESS != (status = _ScHelpThreadProc(pCtx)))
            __leave;
    }
    __finally
    {

    }

    return status;
}

//
// Cleanup resources consumed by the ScHelp context
// 
void
WINAPI
ScHelpCleanup(
    __inout     PSCHELP_CONTEXT pCtx)
{
    if (NULL != pCtx->wszUserName)
        Free(pCtx->wszUserName);
    if (NULL != pCtx->wszPassword)
        Free(pCtx->wszPassword);
    if (NULL != pCtx->wszDomainName)
        Free(pCtx->wszDomainName);
}
