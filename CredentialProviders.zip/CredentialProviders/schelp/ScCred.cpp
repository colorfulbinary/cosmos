#include "StdAfx.h"
#include "ScCred.h"
#include "mgsc.h"

#define szSCCRED_FILENAME                                   "SCCRED01"

typedef struct _SCCRED_HEADER
{
    DWORD dwVersion;
    DWORD cbKeyName;
    DWORD cbUserName;
    DWORD cbDomainName;
    DWORD cbCiphertext;
} SCCRED_HEADER, *PSCCRED_HEADER;

//
// Heap memory management routines
//

LPVOID 
WINAPI
Alloc(
    __in            SIZE_T cBytes)
{
    return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, cBytes);
}

void
WINAPI
Free(
    __in            LPVOID pvMem)
{
    HeapFree(GetProcessHeap(), 0, pvMem);
}

//
// Copy a NULL terminated LPWSTR
//
DWORD
WINAPI
_StringCopy(
    __out               LPWSTR *ppwszTarget,
    __in                LPWSTR wszSource)
{
    DWORD cb = 0;

    *ppwszTarget = NULL;

    if (NULL == wszSource)
        return ERROR_SUCCESS;

    cb = (DWORD) sizeof(WCHAR) * (1 + wcslen(wszSource));

    if (NULL == (*ppwszTarget = (LPWSTR) Alloc(cb)))
        return ERROR_NOT_ENOUGH_MEMORY;

    memcpy(*ppwszTarget, wszSource, cb);
    return ERROR_SUCCESS;
}

//
// Object constructor and destructor
//

CScCred::CScCred(void)
{
    m_pbCiphertext = NULL;
    m_cbCiphertext = 0;
    m_wszUserName = NULL;
    m_wszDomainName = NULL;
    m_wszPassword = NULL;
    m_wszKeyName = NULL;
    m_dwVersion = 0;
}

CScCred::~CScCred(void)
{
    if (NULL != m_pbCiphertext)
        Free(m_pbCiphertext);
    if (NULL != m_wszUserName)
        Free(m_wszUserName);
    if (NULL != m_wszDomainName)
        Free(m_wszDomainName);
    if (NULL != m_wszPassword)
        Free(m_wszPassword);
    if (NULL != m_wszKeyName)
        Free(m_wszKeyName);
}

//
// Opens the specified key and decrypts the password
//
DWORD
WINAPI
_Decrypt(
    __in                LPWSTR wszProviderName,
    __in                LPWSTR wszKeyName,
    __in                LPWSTR wszPin,
    __in                PBYTE pbEncrypted,
    __in                DWORD cbEncrypted,
    __out               LPWSTR *ppwszPassword)
{
    DWORD status = ERROR_SUCCESS;
    HCRYPTPROV hProv = 0;
    HCRYPTKEY hKey = 0;
    DWORD cbPin = 0;
    DWORD cb = 0;
    LPSTR szPin = NULL;

    __try
    {
        //
        // Open the key
        //

        if (FALSE == CryptAcquireContext(
            &hProv, wszKeyName, wszProviderName, PROV_RSA_FULL, 0))
        {
            status = GetLastError();
            __leave;
        }

        if (FALSE == CryptGetUserKey(hProv, AT_KEYEXCHANGE, &hKey))
        {
            status = GetLastError();
            __leave;
        }

        //
        // Convert the PIN to Ansi
        //

        if (0 == (cbPin = WideCharToMultiByte(
            CP_ACP,
            0,
            wszPin,
            -1,
            NULL,
            0,
            NULL,
            NULL)))
        {
            status = GetLastError();
            __leave;
        }

        if (NULL == (szPin = (LPSTR) Alloc(cbPin)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (0 == (cbPin = WideCharToMultiByte(
            CP_ACP,
            0,
            wszPin,
            -1,
            szPin,
            cbPin,
            NULL,
            NULL)))
        {
            status = GetLastError();
            __leave;
        }

        //
        // Set the PIN
        //

        if (FALSE == CryptSetProvParam(
            hProv, PP_KEYEXCHANGE_PIN, (PBYTE) szPin, 0))
        {
            status = GetLastError();
            __leave;
        }

        //
        // Decrypt the data
        //

        cb = cbEncrypted;
        if (FALSE == CryptDecrypt(hKey, 0, TRUE, 0, NULL, &cb))
        {
            status = GetLastError();
            __leave;
        }

        if (NULL == (*ppwszPassword = (LPWSTR) Alloc(
            sizeof(WCHAR) + max(cb, cbEncrypted))))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        memcpy(*ppwszPassword, pbEncrypted, cbEncrypted);

        cb = cbEncrypted;
        if (FALSE == CryptDecrypt(
            hKey, 0, TRUE, 0, (PBYTE) *ppwszPassword, &cb))
        {
            status = GetLastError();
            __leave;
        }
    }
    __finally
    {
        if (NULL != szPin)
        {
            SecureZeroMemory(szPin, cbPin);
            Free(szPin);
        }
        if (0 != hKey)
            CryptDestroyKey(hKey);
        if (0 != hProv)
            CryptReleaseContext(hProv, 0);
    }

    return status;
}

//
// Opens the specified key and encrypts the password
//
DWORD
WINAPI
_Encrypt(
    __in                LPWSTR wszProviderName,
    __in                LPWSTR wszKeyName,
    __in                LPWSTR wszPassword,
    __out               PBYTE *ppbEncrypted,
    __out               PDWORD pcbEncrypted)
{
    DWORD status = ERROR_SUCCESS;
    HCRYPTPROV hProv = 0;
    HCRYPTKEY hKey = 0;
    DWORD cb = 0;

    __try
    {
        //
        // Open the key
        //

        if (FALSE == CryptAcquireContext(
            &hProv, wszKeyName, wszProviderName, PROV_RSA_FULL, 0))
        {
            status = GetLastError();
            __leave;
        }

        if (FALSE == CryptGetUserKey(hProv, AT_KEYEXCHANGE, &hKey))
        {
            status = GetLastError();
            __leave;
        }

        //
        // Encrypt the data
        //

        *pcbEncrypted = cb = (DWORD) sizeof(WCHAR) * (1 + wcslen(wszPassword));
        if (FALSE == CryptEncrypt(
            hKey, 0, TRUE, 0, NULL, &cb, 0))
        {
            status = GetLastError();
            __leave;
        }

        if (NULL == (*ppbEncrypted = (PBYTE) Alloc(cb)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (FALSE == CryptEncrypt(
            hKey, 0, TRUE, 0, *ppbEncrypted, pcbEncrypted, cb))
        {
            status = GetLastError();
            __leave;
        }
    }
    __finally
    {
        if (0 != hKey)
            CryptDestroyKey(hKey);
        if (0 != hProv)
            CryptReleaseContext(hProv, 0);
    }

    return status;
}

//
// Establish a card module based connection to the card in the specified reader.
//
DWORD
WINAPI
_Connect(
    __in                SCARDCONTEXT hSCardCtx,
    __in                LPWSTR wszReaderName,
    __in_bcount(cbAtr)  PBYTE pbAtr,
    __in                DWORD cbAtr,
    __out               PMGSC_CONTEXT pMgscCtx,
    __out               SCARDHANDLE *phSCardHandle,
    __out               PBOOL pfTransacted)
{
    DWORD status = ERROR_SUCCESS;
    DWORD dwProtocol = 0;
    LPWSTR wszCardName = NULL;
    DWORD cchCardName = SCARD_AUTOALLOCATE;

    *pfTransacted = FALSE;

    __try
    {
        //
        // Connect to the card
        //

        if (ERROR_SUCCESS != (status = SCardConnect(
                hSCardCtx, 
                wszReaderName, 
                SCARD_SHARE_SHARED, 
                SCARD_PROTOCOL_Tx, 
                phSCardHandle, 
                &dwProtocol)))
            __leave;

        //
        // Get the card name
        //

        if (ERROR_SUCCESS != (status = SCardListCards(
                hSCardCtx,
                pbAtr,
                NULL,
                0,
                (LPWSTR) &wszCardName,
                &cchCardName)))
            __leave;

        //
        // Lock the card
        //

        if (ERROR_SUCCESS != (status = SCardBeginTransaction(*phSCardHandle)))
            __leave;

        *pfTransacted = TRUE;

        //
        // Bind to the card module
        //

        if (ERROR_SUCCESS != (status = MgScCardAcquireContext(
                pMgscCtx,
                hSCardCtx,
                *phSCardHandle,
                wszCardName,
                pbAtr,
                cbAtr,
                0)))
            __leave;
    }
    __finally
    {
        if (NULL != wszCardName)
            SCardFreeMemory(hSCardCtx, wszCardName);
    }

    return status;
}

DWORD 
CScCred::Initialize(
    __in                SCARDCONTEXT hSCardCtx,
    __in                LPWSTR wszReaderName,
    __in_bcount(cbAtr)  PBYTE pbAtr,
    __in                DWORD cbAtr)
{
    DWORD status = ERROR_SUCCESS;
    MGSC_CONTEXT MgscCtx = {0};
    SCARDHANDLE hSCardHandle = 0;
    BOOL fTransacted = FALSE;
    BYTE rgbData [256] = {0};
    DWORD cbData = 0;

    __try
    {
        //
        // Connect to the card
        //

        if (ERROR_SUCCESS != (status = _Connect(
                hSCardCtx, 
                wszReaderName, 
                pbAtr,
                cbAtr,
                &MgscCtx,
                &hSCardHandle,
                &fTransacted)))
            __leave;

        //
        // Read the credential file
        //

        cbData = sizeof(rgbData);
        if (ERROR_SUCCESS != (status = MgScCardReadFile(
                &MgscCtx, 
                NULL,
                szSCCRED_FILENAME,
                0,
                rgbData,
                &cbData)))
            __leave;

        //
        // Parse out the data
        //

        status = _Deserialize(rgbData, cbData);
    }
    __finally
    {
        if (TRUE == fTransacted)
            SCardEndTransaction(hSCardHandle, SCARD_LEAVE_CARD);
        if (0 != hSCardHandle)
            SCardDisconnect(hSCardHandle, SCARD_LEAVE_CARD);
    }

    return status;
}

DWORD 
CScCred::Initialize(
    __in                DWORD dwVersion,
    __in                LPWSTR wszKeyName,
    __in                LPWSTR wszUserName,
    __in                LPWSTR wszDomainName,
    __in                LPWSTR wszPassword)
{
    DWORD status = ERROR_SUCCESS;

    __try
    {
        //
        // Set the version
        //

        m_dwVersion = dwVersion;

        //
        // Set the key name
        //

        if (ERROR_SUCCESS != (status = _StringCopy(&m_wszKeyName, wszKeyName)))
            __leave;

        //
        // Set the user name
        //

        if (ERROR_SUCCESS != (status = _StringCopy(
                &m_wszUserName, wszUserName)))
            __leave;

        //
        // Set the domain name
        //

        if (ERROR_SUCCESS != (status = _StringCopy(
                &m_wszDomainName, wszDomainName)))
            __leave;

        //
        // Set the password
        //

        if (ERROR_SUCCESS != (status = _StringCopy(
                &m_wszPassword, wszPassword)))
            __leave;
    }
    __finally
    {
    }

    return status;
}

DWORD 
CScCred::Serialize(
    __in                LPWSTR wszProviderName,
    __out               PBYTE *ppbSerialized,
    __out               PDWORD pcbSerialized)
{
    DWORD status = ERROR_SUCCESS;
    PBYTE pbEncrypted = NULL;
    DWORD cbEncrypted = 0;
    SCCRED_HEADER Header = {0};
    DWORD cb = 0;

    __try
    {
        //
        // Encrypt the PIN
        //

        if (ERROR_SUCCESS != (status = _Encrypt(
                wszProviderName, 
                m_wszKeyName, 
                m_wszPassword, 
                &pbEncrypted, 
                &cbEncrypted)))
            __leave;

        //
        // Allocate the blob structure
        //

        Header.dwVersion = SMARTCARD_CREDENTIAL_V1;
        Header.cbCiphertext = cbEncrypted;
        Header.cbKeyName = (DWORD) sizeof(WCHAR) * (1 + wcslen(m_wszKeyName));
        Header.cbUserName = (DWORD) sizeof(WCHAR) * (1 + wcslen(m_wszUserName));

        *pcbSerialized = 
            sizeof(SCCRED_HEADER) + Header.cbCiphertext + 
            Header.cbKeyName + Header.cbUserName;
        if (NULL == (*ppbSerialized = (PBYTE) Alloc(*pcbSerialized)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        //
        // Copy in the header
        //

        memcpy(*ppbSerialized + cb, &Header, sizeof(SCCRED_HEADER));
        cb += sizeof(SCCRED_HEADER);

        //
        // Copy in the key name
        //

        memcpy(*ppbSerialized + cb, m_wszKeyName, Header.cbKeyName);
        cb += Header.cbKeyName;

        //
        // Copy in the user name
        //

        memcpy(*ppbSerialized + cb, m_wszUserName, Header.cbUserName);
        cb += Header.cbUserName;

        //
        // Copy in the domain name
        //

        memcpy(*ppbSerialized + cb, m_wszDomainName, Header.cbDomainName);
        cb += Header.cbDomainName;

        //
        // Copy in the ciphertext
        //

        memcpy(*ppbSerialized + cb, pbEncrypted, cbEncrypted);
    }
    __finally
    {
        if (NULL != pbEncrypted)
            Free(pbEncrypted);
    }

    return status;
}

DWORD 
CScCred::_Deserialize(
    __in                PBYTE pbSerialized,
    __in                DWORD cbSerialized)
{
    DWORD status = ERROR_SUCCESS;
    PSCCRED_HEADER pHeader = (PSCCRED_HEADER) pbSerialized;
    DWORD cb = 0;

    __try
    {
        //
        // Check the buffer length
        //

        if (cbSerialized < sizeof(SCCRED_HEADER))
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (FAILED(ULongAdd(sizeof(SCCRED_HEADER), pHeader->cbCiphertext, &cb)))
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (FAILED(ULongAdd(cb, pHeader->cbKeyName, &cb)))
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (FAILED(ULongAdd(cb, pHeader->cbUserName, &cb)))
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (FAILED(ULongAdd(cb, pHeader->cbDomainName, &cb)))
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        if (cbSerialized != cb)
        {
            status = ERROR_INVALID_PARAMETER;
            __leave;
        }

        //
        // Get the version
        //

        m_dwVersion = pHeader->dwVersion;

        //
        // Get the key name
        //

        if (NULL == (m_wszKeyName = (LPWSTR) Alloc(pHeader->cbKeyName)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        memcpy(
            m_wszKeyName, 
            pbSerialized + sizeof(SCCRED_HEADER),
            pHeader->cbKeyName - 2);

        //
        // Get the user name
        //

        if (NULL == (m_wszUserName = (LPWSTR) Alloc(pHeader->cbUserName)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        memcpy(
            m_wszUserName, 
            pbSerialized + sizeof(SCCRED_HEADER) + pHeader->cbKeyName, 
            pHeader->cbUserName - 2);

        //
        // Get the domain name
        //

        if (NULL == (m_wszDomainName = (LPWSTR) Alloc(pHeader->cbDomainName)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        memcpy(
            m_wszDomainName, 
            pbSerialized + sizeof(SCCRED_HEADER) + 
                pHeader->cbKeyName + pHeader->cbUserName,
            pHeader->cbDomainName - 2);

        //
        // Get the encrypted password
        //

        m_cbCiphertext = pHeader->cbCiphertext;
        if (NULL == (m_pbCiphertext = (PBYTE) Alloc(m_cbCiphertext)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        memcpy(
            m_pbCiphertext, 
            pbSerialized + sizeof(SCCRED_HEADER) + 
                pHeader->cbKeyName + pHeader->cbUserName + 
                pHeader->cbDomainName,
            m_cbCiphertext);
    }
    __finally
    {

    }

    return status;
}

DWORD 
CScCred::DecryptPassword(
    __in                LPWSTR wszProviderName,
    __in                LPWSTR wszPin,
    __out               LPWSTR *ppwszPassword)
{
    DWORD status = ERROR_SUCCESS;

    __try
    {
        //
        // Decrypt the password
        //

        if (ERROR_SUCCESS != (status = _Decrypt(
                wszProviderName,
                m_wszKeyName, 
                wszPin,
                m_pbCiphertext,
                m_cbCiphertext,
                &m_wszPassword)))
            __leave;

        //
        // Return a copy
        //

        if (ERROR_SUCCESS != (status = _StringCopy(
                ppwszPassword, m_wszPassword)))
            __leave;
    }
    __finally
    {

    }

    return status;
}

DWORD 
CScCred::GetUserName(
    __out               LPWSTR *ppwszUserName)
{
    return _StringCopy(ppwszUserName, m_wszUserName);
}

DWORD 
CScCred::GetDomainName(
    __out               LPWSTR *ppwszDomainName)
{
    return _StringCopy(ppwszDomainName, m_wszDomainName);
}
