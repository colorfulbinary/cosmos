#pragma once

#include "stdafx.h"
#include "ScCred.h"

//
// Type definition for callback to be provided by the caller
//
typedef DWORD (WINAPI *PFN_SCWATCH_NOTIFY)(PVOID pvContext);

//
// This class allows the caller to monitor for an inserted smart card on a 
// separate thread.  If a card is inserted or removed, the specified callback
// function will be called.
//
class CScWatch
{
public:
    
    //
    // Default c'tor
    //
    CScWatch(void);

    //
    // D'tor
    //
    ~CScWatch(void);

    //
    // Call this after the constructor to initialize the class
    //
    DWORD
    Initialize(
        __in            PFN_SCWATCH_NOTIFY pfnScWatchNotify,
        __in            PVOID pvContext);

    //
    // Stop monitoring for an inserted smart card 
    //
    DWORD
    Stop(void);

protected:

    //
    // Trusted C routines
    //
    friend DWORD WINAPI _ScWatchThreadProc(__in LPVOID pvParam);

    //
    // Grab the credentials from the card inserted in the specified reader
    //
    DWORD
    CScWatch::_AddCard(
        __in            PSCARD_READERSTATE pReader);

    //
    // Forget the credentials, if any, from the card previously inserted in the
    // specified reader.
    //
    DWORD
    CScWatch::_RemoveCard(
        __in            PSCARD_READERSTATE pReader);

    //
    // Wait for the resource manager to start, then connect and enumerate readers
    // and cards in a loop.
    //
    DWORD
    _ResourceManagerLoop(void);

    //
    // Member variables
    //

    CScCred *m_pScCred;
    SCARDCONTEXT m_hSCardCtx;
    HANDLE m_hStop;
    PFN_SCWATCH_NOTIFY m_pfnScWatchNotify;
    PVOID m_pvContext;
    HANDLE m_hThread;
    DWORD m_dwThreadId;
    CRITICAL_SECTION m_cs;
    BOOL m_fInitCS;
    BOOL m_fInitialized;
};
