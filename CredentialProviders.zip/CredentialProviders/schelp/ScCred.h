#pragma once

#define SMARTCARD_CREDENTIAL_V1                             1

class CScCred
{
public:
    
    //
    // C'tor
    //
    CScCred(void);

    //
    // D'tor
    //
    ~CScCred(void);

    //
    // Initialize the object from the credential (if any) stored on the card
    // card in the specified reader
    //
    DWORD Initialize(
        __in                SCARDCONTEXT hSCardCtx,
        __in                LPWSTR wszReaderName,
        __in_bcount(cbAtr)  PBYTE pbAtr,
        __in                DWORD cbAtr);

    //
    // Initialize the object from the provided credential data
    //
    DWORD Initialize(
        __in                DWORD dwVersion,
        __in                LPWSTR wszKeyName,
        __in                LPWSTR wszUserName,
        __in                LPWSTR wszDomainName,
        __in                LPWSTR wszPassword);

    //
    // Flatten a smart card credential into a byte array for storage
    //
    DWORD Serialize(
        __in                                    LPWSTR wszProviderName,
        __out_bcount(*pcbSerialized)            PBYTE *ppbSerialized,
        __out                                   PDWORD pcbSerialized);

    //
    // Use the specified PIN to decrypt the password
    //
    DWORD DecryptPassword(
        __in                LPWSTR wszProviderName,
        __in                LPWSTR wszPin,
        __out               LPWSTR *ppwszPassword);

    //
    // Returns a copy of the user name member
    //
    DWORD GetUserName(
        __out               LPWSTR *ppwszUserName);

    //
    // Returns a copy of the user name member
    //
    DWORD GetDomainName(
        __out               LPWSTR *ppwszDomainName);

private:

    //
    // Reconstitute this smart card credential from a byte array
    //
    DWORD _Deserialize(
        __in_bcount(cbSerialized)               PBYTE pbSerialized,
        __in                                    DWORD cbSerialized);

    PBYTE m_pbCiphertext;
    DWORD m_cbCiphertext;
    LPWSTR m_wszUserName;
    LPWSTR m_wszDomainName;
    LPWSTR m_wszPassword;
    LPWSTR m_wszKeyName;
    DWORD m_dwVersion;
};
