#include "StdAfx.h"
#include "ScWatch.h"

#define dwDEFAULT_SPIN_COUNT                                    4000

//
// Heap memory management routines
//

LPVOID 
WINAPI
Alloc(
    __in            SIZE_T cBytes)
{
    return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, cBytes);
}

void
WINAPI
Free(
    __in            LPVOID pvMem)
{
    HeapFree(GetProcessHeap(), 0, pvMem);
}

//
// Free resources consumed by an array of reader states
//
void
WINAPI
_ScWatchFreeReaderStateArray(
    __inout         PSCARD_READERSTATE pStates,
    __in            DWORD cStates)
{
    DWORD iState = 0;

    if (NULL == pStates)
        return;

    for (iState = 1; iState < cStates; iState++)
        Free(pStates [iState].szReader);

    Free(pStates);
}

//
// Build an array of SCARD_READERSTATEs.
//
// This routine is currently limited to only use the first returned reader.  
// The Plug-and-Play notification reader is added to the list as well in
// order to receive insertion and removal notification.
//
DWORD
WINAPI
_ScWatchBuildReaderStateArray(
    __in            SCARDCONTEXT hSCardCtx,
    __inout         PSCARD_READERSTATE *ppStates,
    __inout         PDWORD pcStates)
{
    DWORD status = ERROR_SUCCESS;
    LPTSTR mszReaders = NULL;
    DWORD cchReaders = 0;
    PSCARD_READERSTATE pNewStates = NULL;
    DWORD cNewStates = 0;
    DWORD iState = 0;

    __try
    {
        //
        // Get available readers
        //

        if (ERROR_SUCCESS != (status = SCardListReaders(
                hSCardCtx, NULL, NULL, &cchReaders)))
            __leave;

        if (NULL == (mszReaders = (LPTSTR) Alloc(sizeof(TCHAR) * cchReaders)))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (ERROR_SUCCESS != (status = SCardListReaders(
                hSCardCtx, NULL, mszReaders, &cchReaders)))
            __leave;

        //
        // Was at least one reader enumerated?
        //

        if (NULL != mszReaders)
            cNewStates = 2;
        else
            cNewStates = 1;

        //
        // Create the new array
        //

        if (NULL == (pNewStates = (PSCARD_READERSTATE) Alloc(
            cNewStates * sizeof(SCARD_READERSTATE))))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        //
        // Setup the notification reader
        //

        pNewStates [0].szReader = TEXT("\\\\?PNP?\\NOTIFICATION");
        if (NULL != *ppStates)
            pNewStates [0].dwCurrentState = (*ppStates) [0].dwCurrentState;

        //
        // Setup the 'real' reader, if any
        //

        if (1 < cNewStates)
        {
            pNewStates [1].szReader = mszReaders;
            mszReaders = NULL;
            pNewStates [1].dwCurrentState = SCARD_STATE_UNAWARE;

            if (NULL != *ppStates && 1 < *pcStates)
            {
                //
                // Check if we have a more up to date status for this reader
                //

                for (iState = 1; iState < *pcStates; iState++)
                {
                    if (0 == _tcscmp(
                            pNewStates [1].szReader, 
                            (*ppStates) [iState].szReader))
                        pNewStates [1].dwCurrentState = 
                            (*ppStates) [iState].dwCurrentState;
                }
            }
        }

        if (NULL != *ppStates)
            _ScWatchFreeReaderStateArray(*ppStates, *pcStates);

        *ppStates = pNewStates;
        pNewStates = NULL;
        *pcStates = cNewStates;
    }
    __finally
    {
        if (NULL != mszReaders)
            Free(mszReaders);
        if (NULL != pNewStates)
            _ScWatchFreeReaderStateArray(pNewStates);
    }

    return status;
}

//
// This is the thread entry point procedure for monitoring for smart card and
// reader insertion and removal.  
//
// The loop is intended to continue until cancelled by another application 
// thread.
//
DWORD
WINAPI
_ScWatchThreadProc(
    __in            LPVOID pvParam)
{
    DWORD status = ERROR_SUCCESS;
    CScWatch *pWatcher = (CScWatch *) pvParam;

    while (WAIT_TIMEOUT == WaitForSingleObject(
        pWatcher->m_hStop, 0))
    {
        if (SCARD_E_CANCELLED == (status = pWatcher->_ResourceManagerLoop()))
            return status;
    }

    return status;
}

//
// Smart card watcher class implementation
//

CScWatch::CScWatch(void)
{
    m_hStop = 0;
    m_hSCardCtx = 0;
    m_pfnScWatchNotify = NULL;
    m_pvContext = NULL;
    m_hThread = 0;
    m_fInitCS = FALSE;
    m_fInitialized = FALSE;
    m_pScCred = NULL;
}

CScWatch::~CScWatch(void)
{
    if (NULL != m_pScCred)
        delete m_pScCred;
    if (0 != m_hSCardCtx)
        SCardReleaseContext(m_hSCardCtx);
    if (0 != m_hThread)
        CloseHandle(m_hThread);
    if (TRUE == m_fInitCS)
        DeleteCriticalSection(&m_cs);
}

DWORD
CScWatch::_AddCard(
    __in            SCARDCONTEXT hSCardCtx,
    __in            PSCARD_READERSTATE pReader)
{
    DWORD status = ERROR_SUCCESS;
    CScCred *pScCred = NULL;

    __try
    {
        //
        // Initialize the smart card credential from this reader
        //

        if (NULL == (pScCred = new CScCred()))
        {
            status = ERROR_NOT_ENOUGH_MEMORY;
            __leave;
        }

        if (ERROR_SUCCESS != (status = pScCred->Initialize(
                hSCardCtx, pReader->szReader, pReader->rgbAtr, pReader->cbAtr)))
            __leave;

        //
        // Save the cred 
        //

        EnterCriticalSection(&m_cs);
        if (NULL != m_pScCred)
            delete m_pScCred;
        m_pScCred = pScCred;
        pScCred = NULL;
        LeaveCriticalSection(&m_cs);

        //
        // Notify the consumer 
        //

        m_pfnScWatchNotify(m_pvContext);
    }
    __finally
    {
        if (NULL != pScCred)
            delete pScCred;
    }

    return status;
}

DWORD
CScWatch::_RemoveCard(
    __in            PSCARD_READERSTATE pReader)
{
    UNREFERENCED_PARAMETER(pReader);

    EnterCriticalSection(&m_cs);
    if (NULL != m_pScCred)
    {
        delete m_pScCred;
        m_pScCred = NULL;
    }
    LeaveCriticalSection(&m_cs);

    return ERROR_SUCCESS;
}

DWORD
CScWatch::_ResourceManagerLoop(void)
{
    DWORD status = ERROR_SUCCESS;
    HANDLE rghEvents [2];
    BOOL fInCS = FALSE;
    PSCARD_READERSTATE pStates = NULL;
    DWORD cStates = 0;

    __try
    {
        //
        // Connect to the smart card subsystem
        //

        if (NULL == (rghEvents [0] = SCardAccessStartedEvent()))
        {
            status = GetLastError();
            __leave;
        }

        rgEvents [1] = m_hStop;

        if (WAIT_OBJECT_0 != (status = WaitForMultipleObjects(
            sizeof(rghEvents) / sizeof(rghEvents [0]),
            rghEvents,
            FALSE,
            INFINITE)))
        {
            status = SCARD_E_CANCELLED;
            __leave;
        }

        EnterCriticalSection(&m_cs);
        fInCS = TRUE;

        if (ERROR_SUCCESS != (status = SCardEstablishContext(
                SCARD_SCOPE_USER, NULL, NULL, &m_hSCardCtx)))
            __leave;

        //
        // Continuously refresh the smart card reader states
        //

        while (TRUE)
        {
            //
            // Update our list of currently available smart card readers
            //

            if (ERROR_SUCCESS != (status = _ScWatchBuildReaderStateArray(
                    m_SCardCtx, &pStates, &cStates)))
                __leave;

            //
            // Before we block, make sure we haven't been asked to stop
            //

            if (WAIT_TIMEOUT != (status = WaitForSingleObject(
                m_hStop, INFINITE)))
            {
                status = SCARD_E_CANCELLED;
                __leave;
            }

            LeaveCriticalSection(&m_cs);
            fInCS = FALSE;

            //
            // Wait for a state change
            //

            if (ERROR_SUCCESS != (status = SCardGetStatusChange(
                    m_SCardCtx, INFINITE, pStates, cStates)))
                __leave;

            //
            // Is there a card present?
            //

            if (1 < cStates && pStates [1].dwEventState & SCARD_STATE_PRESENT)
                _AddCard(pStates + 1);
            else if (   1 < cStates && 
                        pStates [1].dwEventState & SCARD_STATE_EMPTY)
                _RemoveCard(pStates + 1);
        }
    }
    __finally
    {
        if (TRUE == fInCS)
            LeaveCriticalSection(&m_cs);
        if (NULL != pStates)
            _ScWatchFreeReaderStateArray(pStates, cStates);
    }

    return status;
}

DWORD
CScWatch::Initialize(
    __in        PFN_SCWATCH_NOTIFY pfnScWatchNotify,
    __in        PVOID pvContext)
{
    DWORD status = ERROR_SUCCESS;

    m_pfnScWatchNotify = pfnScWatchNotify;
    m_pvContext = pvContext;

    __try
    {
        //
        // Initialize our critsec.  This way, low memory shouldn't cause an 
        // exception to be thrown.
        //

        if (FALSE == InitializeCriticalSectionAndSpinCount(
            &m_cs, dwDEFAULT_SPIN_COUNT))
        {
            status = GetLastError();
            __leave;
        }

        m_fInitCS = TRUE;

        //
        // Create our watcher thread
        //

        if (NULL == (m_hThread == CreateThread(
            NULL,
            0,
            CScWatch,
            NULL,
            0,
            &m_dwThreadId)))
        {
            status = GetLastError();
            __leave;
        }

        //
        // We're fully initialized
        //

        m_fInitialized = TRUE;
    }
    __finally
    {
    }

    return status;
}

void
CScWatch::Stop(void)
{
    EnterCriticalSection(&m_cs);

    SCardCancel(m_hSCardCtx);
    SetEvent(m_hStop);

    LeaveCriticalSection(&m_cs);

    WaitForSingleObject(m_hThread, INFINITE);
}

