#pragma once

typedef struct _MGSC_CONTEXT
{
    //
    // Internal context
    //

    PVOID                           pvContext;

} MGSC_CONTEXT, *PMGSC_CONTEXT;

#ifdef __cplusplus
extern "C" {
#endif

__declspec(dllexport)
long
WINAPI
MgScSCardUIDlgSelectCardW(
    __inout         LPOPENCARDNAMEW_EX pOcne);

__declspec(dllexport)
DWORD
WINAPI
MgScCardAcquireContext(
    __inout                     PMGSC_CONTEXT pData,
    __in                        SCARDCONTEXT hSCardContext,
    __in                        SCARDHANDLE hSCardHandle,
    __in                        LPWSTR wszCardName,
    __in_bcount(cbAtr)          PBYTE pbAtr,
    __in                        DWORD cbAtr,
    __in                        DWORD dwFlags);

__declspec(dllexport)
DWORD 
WINAPI
MgScCardAuthenticatePin(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPWSTR      pwszUserId,
    __in_bcount(cbPin)          PBYTE       pbPin,
    __in                        DWORD       cbPin,
    __out_opt                   PDWORD      pcAttemptsRemaining);

__declspec(dllexport)
DWORD 
WINAPI
MgScCardCreateFile(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPSTR       pszDirectoryName,
    __in                        LPSTR       pszFileName,
    __in                        DWORD       cbInitialCreationSize,
    __in                        CARD_FILE_ACCESS_CONDITION AccessCondition);

__declspec(dllexport)
DWORD 
WINAPI
MgScCardDeauthenticate(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPWSTR      pwszUserId,
    __in                        DWORD       dwFlags);

__declspec(dllexport)
void
WINAPI
MgScCardDeleteContext(
    __inout                     PMGSC_CONTEXT pData);

__declspec(dllexport)
DWORD 
WINAPI
MgScCardDeleteFile(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPSTR       pszDirectoryName,
    __in                        LPSTR       pszFileName,
    __in                        DWORD       dwFlags);

__declspec(dllexport)
DWORD
WINAPI
MgScCardReadFile(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPSTR       pszDirectoryName,
    __in                        LPSTR       pszFileName,
    __in                        DWORD       dwFlags,
    __out_bcount_opt(*pcbData)  PBYTE       pbData,
    __inout                     PDWORD      pcbData);

__declspec(dllexport)
DWORD
WINAPI
MgScCardWriteFile(
    __in                        PMGSC_CONTEXT pData,
    __in                        LPSTR       pszDirectoryName,
    __in                        LPSTR       pszFileName,
    __in                        DWORD       dwFlags,
    __in_bcount(cbData)         PBYTE       pbData,
    __in                        DWORD       cbData);

#ifdef __cplusplus
}
#endif
