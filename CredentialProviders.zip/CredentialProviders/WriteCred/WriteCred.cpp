// WriteCred.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "mgsc.h"
#include "schelp.h"

//
// Flow macros
// 

#define TRY_DWORD(_X) {                                                 \
    if (ERROR_SUCCESS != (status = (_X))) {                             \
        __leave;                                                        \
    }                                                                   \
}

#define TRY_ALLOC(_X) {                                                 \
    if (NULL == (_X)) {                                                 \
        status = ERROR_NOT_ENOUGH_MEMORY;                               \
        __leave;                                                        \
    }                                                                   \
}

#define TRY_BOOL(_X) {                                                  \
    if (FALSE == (_X)) {                                                \
        status = GetLastError();                                        \
        __leave;                                                        \
    }                                                                   \
}

int _tmain(int argc, _TCHAR* argv[])
{
    DWORD status = ERROR_SUCCESS;
    BOOL fInvalidParam = FALSE;
    LPWSTR wszUserName = NULL;
    LPWSTR wszPassword = NULL;
    LPWSTR wszDomainName = NULL;
    LPWSTR wszPin = NULL;
    SCARDCONTEXT hSCardCtx = NULL;
    LPWSTR wszReaders = NULL;
    DWORD cchReaders = SCARD_AUTOALLOCATE;
    MGSC_CONTEXT MgscContext = {0};
    BOOL fCleanupMgsc = FALSE;
    SCARDHANDLE hCard = NULL;
    DWORD dwProtocol = 0;
    LPWSTR wszReader = NULL;
    DWORD cchReader = SCARD_AUTOALLOCATE;
    DWORD dwState = 0;
    PBYTE pbAtr = NULL;
    DWORD cbAtr = SCARD_AUTOALLOCATE;
    LPWSTR wszCards = NULL;
    DWORD cchCards = SCARD_AUTOALLOCATE;
    PBYTE pbCred = NULL;
    DWORD cbCred = 0;
    BOOL fTransacted = FALSE;
    LPSTR szPin = NULL;
    DWORD cbPin = 0;

    __try
    {
        //
        // Read the command line options
        //

        --argc;
        ++argv;

        while (argc)
        {
            if (L'/' != **argv && L'-' != **argv)
            {
                fInvalidParam = TRUE;
                __leave;
            }

            switch (argv [0][1])
            {
            case L'p':
                --argc;
                ++argv;
                wszPin = *argv;
                break;

            case L'u':
                --argc;
                ++argv;
                wszUserName = *argv;
                break;

            case L'd':
                --argc;
                ++argv;
                wszDomainName = *argv;
                break;

            case L'w':
                --argc;
                ++argv;
                wszPassword = *argv;
                break;

            default:
                fInvalidParam = TRUE;
                __leave;
            }

            --argc;
            ++argv;
        }

        if (NULL == wszPin || 
            NULL == wszUserName || 
            NULL == wszDomainName || 
            NULL == wszPassword)
        {
            fInvalidParam = TRUE;
            __leave;
        }

        //
        // Serialize the credential
        // 

        TRY_DWORD(ScHelpPackCred(
            wszUserName,
            wszPassword,
            wszDomainName,
            NULL,
            &cbCred));

        TRY_ALLOC(pbCred = (PBYTE) LocalAlloc(0, cbCred));

        TRY_DWORD(ScHelpPackCred(
            wszUserName,
            wszPassword,
            wszDomainName,
            pbCred,
            &cbCred));

        //
        // Convert the PIN to ANSI
        // 

        if (0 == (cbPin = WideCharToMultiByte(
            CP_ACP,
            0,
            wszPin,
            -1,
            NULL,
            0,
            NULL,
            NULL)))
        {
            status = GetLastError();
            __leave;
        }

        TRY_ALLOC(szPin = (LPSTR) LocalAlloc(0, cbPin));

        if (0 == (cbPin = WideCharToMultiByte(
            CP_ACP,
            0,
            wszPin,
            -1,
            szPin,
            cbPin,
            NULL,
            NULL)))
        {
            status = GetLastError();
            __leave;
        }

        //
        // Bind to a smart card
        //

        TRY_DWORD(SCardEstablishContext(
            SCARD_SCOPE_USER,
            NULL,
            NULL,
            &hSCardCtx));

        TRY_DWORD(SCardListReaders(
            hSCardCtx,
            NULL,
            (LPWSTR) &wszReaders,
            &cchReaders));

        TRY_DWORD(SCardConnect(
            hSCardCtx,
            wszReaders,
            SCARD_SHARE_SHARED,
            SCARD_PROTOCOL_Tx,
            &hCard,
            &dwProtocol));

        TRY_DWORD(SCardStatus(
            hCard,
            (LPWSTR) &wszReader,
            &cchReader,
            &dwState,
            &dwProtocol,
            (PBYTE) &pbAtr,
            &cbAtr));

        TRY_DWORD(SCardListCards(
            hSCardCtx,
            pbAtr,
            NULL,
            0,
            (LPWSTR) &wszCards,
            &cchCards));

        TRY_DWORD(MgScCardAcquireContext(
            &MgscContext,
            hSCardCtx,
            hCard,
            wszCards,
            pbAtr,
            cbAtr,
            0));

        fCleanupMgsc = TRUE;

        //
        // Write the cred to the card
        //

        TRY_DWORD(SCardBeginTransaction(hCard));

        fTransacted = TRUE;

        TRY_DWORD(MgScCardAuthenticatePin(
            &MgscContext,
            wszCARD_USER_USER,
            (PBYTE) szPin,
            cbPin - sizeof(CHAR),
            NULL));

		MgScCardDeleteFile(
			&MgscContext, NULL, szSCCRED_FILENAME, 0);

		TRY_DWORD(MgScCardCreateFile(
			&MgscContext, NULL, szSCCRED_FILENAME, cbCred, EveryoneReadUserWriteAc));

        TRY_DWORD(MgScCardWriteFile(
            &MgscContext,
            NULL,
            szSCCRED_FILENAME,
            0,
            pbCred,
            cbCred));

        if (ERROR_SUCCESS == MgScCardDeauthenticate(
            &MgscContext,
            wszCARD_USER_USER,
            0))
        {
            TRY_DWORD(SCardEndTransaction(hCard, SCARD_LEAVE_CARD));
            fTransacted = FALSE;
        }
    }
    __finally
    {
        if (NULL != wszReaders)
            SCardFreeMemory(hSCardCtx, wszReaders);
        if (NULL != wszReader)
            SCardFreeMemory(hSCardCtx, wszReader);
        if (NULL != pbAtr)
            SCardFreeMemory(hSCardCtx, pbAtr);
        if (NULL != wszCards)
            SCardFreeMemory(hSCardCtx, wszCards);
        if (TRUE == fTransacted)
            SCardEndTransaction(hCard, SCARD_RESET_CARD);
        if (NULL != hCard)
            SCardDisconnect(hCard, SCARD_LEAVE_CARD);
        if (TRUE == fCleanupMgsc)
            MgScCardDeleteContext(&MgscContext);
        if (NULL != hSCardCtx)
            SCardReleaseContext(hSCardCtx);
        if (NULL != szPin)
            LocalFree(szPin);
        if (NULL != pbCred)
            LocalFree(pbCred);
    }

    return 0;
}

